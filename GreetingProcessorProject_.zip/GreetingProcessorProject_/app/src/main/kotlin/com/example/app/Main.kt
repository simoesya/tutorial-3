package com.example.app

fun main() {
    println("=== Greeting Processor ===")

    val myClass = MyClass()
    val wrappedMyClass = MyClassWrapper(myClass)

    wrappedMyClass.sayHello()
    wrappedMyClass.compute()

    println()
    println("=== Regex Processor ===")

    val input = "Name: John Address: 123 Street"
    val extractor = DataProcessorExtractor(input)

    println("Name: ${extractor.getName()}")
    println("Address: ${extractor.getAddress()}")
}